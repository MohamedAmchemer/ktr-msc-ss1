package Character;
import Movable.Movable;

//Character class
public abstract class Character implements Movable{
     protected String name;
     protected String RPGClass = "Character";
     protected int life;
     protected int agility;
     protected int strength;
     protected int wit;
     

     public Character(String name) {
         this.name = name;
         this.RPGClass = "Character";
         this.life = 50;
         this.agility = 2;
         this.strength= 2;
         this.wit = 2;
     }
     
     /****Getters****/
     public String getName() {
    	 return this.name;
     }
     public String getRPGClass() {
    	 return this.RPGClass;
     }
     public int getLife() {
    	 return this.life;
     }
     public int getAgility() {
    	 return this.agility;
     }
     public int getStrength() {
    	 return this.strength;
     }
     public int getWit() {
    	 return this.wit;
     }
     
     
	 // attack method
	 public void attack(String  weapon ) {
	     System.out.println(this.name + " : Rrrrrrrrrrr...." );
	
	 }
	 
	//Interface methods
	public void moveRight() {
		System.out.println(this.name + " : moves right " );
	}
	public void moveLeft() {
		System.out.println(this.name + " : moves left " );
	}
	public void moveForward() {
		System.out.println(this.name + " : moves back " );
	}
	public void moveBack() {
		System.out.println(this.name + " : moves forward " );
	}
	
	//
	public final void unsheathe(String weapon) {
		System.out.println(this.name + " : unsheathes his " + weapon );
	}
}