package Mage;

import Character.Character;

public class Mage extends Character {

	public Mage(String name ) {
		super(name);
		this.RPGClass = "Mage";
		this.life = 70;
		this.strength = 3;
		this.agility = 10;
		this.wit = 10;
		System.out.println(this.name + " : May the gods be with me." );
	}
	
	// attack method
	public void attack(String  weapon ){	
		if(weapon.equals("magic") || weapon.equals("wand")) {
			super.attack(weapon);
		    System.out.println(this.name + " : Fell the power of my " + weapon );
		}
	}
	
	//Interface methods
	public void moveRight() {
		System.out.println(this.name + " : moves right furtively " );
	}
	public void moveLeft() {
		System.out.println(this.name + " : moves left furtively" );
	}
	public void moveForward() {
		System.out.println(this.name + " : moves back furtively" );
	}
	public void moveBack() {
		System.out.println(this.name + " : moves forward furtively" );
	}

}
