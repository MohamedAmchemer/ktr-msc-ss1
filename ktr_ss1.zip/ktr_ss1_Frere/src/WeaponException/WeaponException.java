package WeaponException;

public class WeaponException extends Exception{

	public WeaponException(String name) {
		System.out.println(name + " : I refuse to fight with my bare hands.");
	}
	
	public WeaponException(String name, String RPGClass, String weapon) {
		if(RPGClass.equals("Warrior")) {
			System.out.println(name + " : A " + weapon + "?? What should I do with this?!");
		}else if(RPGClass.equals("Mage")) {
			System.out.println(name + " : I don't need this stupid " + weapon + "! Don't misjudge my powers!");
		}
	}

}
