package Movable;

public interface Movable {
	public void moveRight();
	public void moveLeft();
	public void moveForward();
	public void moveBack();
}
