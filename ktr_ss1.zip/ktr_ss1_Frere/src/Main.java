
import Character.Character;
import Warrior.Warrior;
import Mage.Mage;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Warrior warrior = new Warrior("Jean-Luc");
		Character mage = new Mage("Robert");
		
		/*
		warrior.attack("hammer");
		warrior.attack("magic");
		
		mage.attack("magic");
		mage.attack("hammer");*/
		
		warrior.moveRight();
		warrior.moveLeft();
		warrior.moveBack();
		warrior.moveForward();
		
		mage.moveRight();
		mage.moveLeft();
		mage.moveBack();
		mage.moveForward();
		
		warrior.unsheathe("hammer");
	}

}
